import React, { useState, useEffect } from "react";

export const Search = ({ labelText, data, filterColumn }) => {
  const [original, setOriginal] = useState(null);
  const [filteredData, setFilteredData] = useState();
  useEffect(() => {
    setOriginal(data);
  }, [data]);
  return (
    <div className="form-group">
      <label htmlFor="inputSearchCharacters" className="form-label mt-4">
        {labelText}
      </label>
      <input
        type="search"
        className="form-control"
        id="inputSearchCharacters"
        placeholder="Enter Search Characters!"
        onChange={(e) => {
          if (e.target.value) {
            setFilteredData(
              data.filter((filterValue) =>
                filterValue[filterColumn]
                  .toLocaleLowerCase()
                  .includes(e.target.value.toLocaleLowerCase())
              )
            );
          } else {
            setFilteredData(original);
          }
        }}
      />
    </div>
  );
};
